
  <?php
        $con = mysqli_connect('localhost', 'root', '', 'krushi2020');
            if (!$con) {
                die("database connection failed");
            }
        ?>
