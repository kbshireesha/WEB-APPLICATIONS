<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style type="text/css">
<!--
.style1 {
	font-size: 14px;
	font-weight: bold;
	font-family: Forte;
}
.style2 {font-size: 18px}
.style3 {font-family: Forte}
.style4 {font-size: 18px; font-family: Forte; }
.style5 {font-size: 24px}
.style6 {font-size: 24}
.style7 {
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
	font-weight: bold;
	font-size: 18px;
	color: #FFFFFF;
}
.style8 {font-size: 24px; font-family: Forte; }
-->
</style>
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">        </div>
        <nav>    <ul>
                <li><span class="style2"><span class="style3"><span class="style5"><span class="style6"><span class="style2"><span class="style5"><a href="aboutus.php">About</a></span></span></span></span></span></span></li>
                <li class="style8"><a href="contact.php">Contact</a></li>
           		 <li class="style8"><a href="signin.php">SignIn</a></li>
          		 <li class="style8"> <a href="signup.php">SignUp->Buyer</a></li>
				  <li class="style8"> <a href="signupseller.php">SignUp->Seller</a></li>    </ul>
        </nav>
        <span class="style8"><a href="shop.php"><img src="cart.PNG" width="30px" height="30px"></a></span><span class="style5">        </span></div> 
<div class="row"></div>
</div>
</div>
</div>
<!------ featured categories ------>
<div class="row"><form name="form1" method="post" action="">
  <p>&nbsp;	</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <table width="635" height="299" BORDER=0 align="center">
    <tr>
      <td colspan="2" bgcolor="#000000"><div align="center" class="style7">SIGN UP</div></td>
      </tr>
    <tr>
      <td width="127"><span class="style4">Register As</span></td>
      <td width="245"><input name="a" type="text" id="a" value="Seller" readonly="" placeholder="seller"></td>
      </tr>
    <tr>
      <td> <span class="style4">Name</span></td>
      <td><label>
        <input type="text" name="b" id="b" pattern="[A-Za-z]+" title="letters only" required="required" />
      </label></td>
      </tr>
    <tr>
      <td><span class="style4">Mobileno</span></td>
      <td><input name="c" type="text" id="c" maxlength="10"  placeholder="Phone or Mobile no"  pattern="^\d{10}$" title="only nos should be 10 digits" required="required"/></td>
      </tr>
    <tr>
      <td><span class="style4">DOB</span></td>
      <td><input type="date" name="textfield" id="textfield">
        <input type="text" name="textfield2" id="textfield2" value="<?php  $d=date("Y-m-d"); echo $d;  ?>"></td>
    </tr>
    <tr>
      <td><span class="style4">Photo</span></td>
      <td><input type="file" name="e" id="e"></td>
      </tr>
    <tr>
      <td><span class="style4">Email</span></td>
      <td><input type="text" name="f" id="f" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Add '@' and '.' operator" required="required"/></td>
      </tr>
    <tr>
      <td><span class="style4">Password</span></td>
      <td><input type="password" name="g" id="textfield72" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required="required"/></td>
      </tr>
    <tr>
      <td><span class="style4">Confirm Password</span></td>
      <td><input type="password" name="h" id="f" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required="required"/></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="button" id="button" value="Submit">
          <input type="reset" name="button2" id="button2" value="Reset"> 
          <a href="signin.php" class="style1">Has an Account ?</a></td>
      </tr>
  </table>
  </form>
  <div align="center"></div>

</div>
<div class="categories">
  <table width="62%" border="0" align="center" cellpadding="10">
    <tr>
      <td width="34%">&nbsp;</td>
      <td width="49%"><?php include "dbcon.php" ?>
          <?php 

if (isset($_POST['button']))
{

$a=$_POST["a"];
$b=$_POST["b"];
$c=$_POST["c"];
$d=$_POST["textfield"];
$e=$_POST["e"];
$f=$_POST["f"];
$g=$_POST["g"];
$h=$_POST["h"];

$d1=$_POST["textfield2"];

$dt1=$_POST["textfield"];
$dt2=$_POST["textfield2"];

$date1 = new DateTime($dt1);
$date2 = new DateTime($dt2);

$diff = $date1->diff($date2);
                  
//echo $diff->days .' days ';
if ($diff->days >6570)
{
if($g==$h)
{
$sql="select * from seller where  email='{$f}'";
$found=0;
$result=$con->query($sql);
if($result ->num_rows == 1)
{	
	$found=1;
}
	
	if($found==0)
	{

$query = "insert into seller  values('$a','$b','$c','$d','$e','$f','$g')";
//echo $query;
mysqli_query($con,$query);

echo "<h3 align = center>Registered successfully </h3>";
}
else
{
		echo("<h4 align=center>Sorry ,User already Registered...</h4>");		
}
}
else
{
			echo("<h4 align=center>Passwords do not match</h4>");

}

}
else
{
	echo "<h1  align=center>You should be 18yrs and above</h1>";

}
}


/*if($g==$h)
{
$sql="select * from user where  email='{$f}'";
$found=0;
$result=$con->query($sql);
if($result ->num_rows == 1)
{	
	$found=1;
}
	
	if($found==0)
	{

$query = "insert into user  values('$a','$b','$c','$d','$e','$f','$g')";
//echo $query;
mysqli_query($con,$query);

echo "<h3 align = center>Registered successfully </h3>";
}
else
{
		echo("<h4 align=center>Sorry ,User already Registered...</h4>");		
}
}
else
{
			echo("<h4 align=center>Passwords do not match</h4>");

}*/


?></td>
      <td width="17%">&nbsp;</td>
    </tr>
  </table>
</div>
<!------ featured products ------>
</body>
</html>