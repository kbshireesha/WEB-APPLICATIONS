<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style type="text/css">
<!--
.style1 {font-family: Forte}
.style2 {
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
	font-weight: bold;
	color: #FFFFFF;
}
.style3 {font-size: 24px}
.style4 {font-family: Forte; font-size: 24px; }
-->
</style>
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">        </div>
        <span class="style4">
        <nav>    </nav>
        </span>
        <span class="style3">
        <nav></nav>
        </span>
        <nav><ul>
                    <li class="style4"><a href="edpwdb.php">Edit Password</a></li>
                <li class="style4"><a href="cart.php"> Cart</a></li>
                <li class="style4"><a href="orderhistory.php">Order History</a></li>
                <li class="style4"><a href="feedback.php">Feedback</a></li>
                <li><span class="style4"><a href="index.php">signout</a></span></li>
            </ul>
      </nav>
</div> 
<div class="row"></div>
</div>
</div>
</div>
<!------ featured categories ------>
<div class="row"><form name="form1" method="post" action="">
  <p>&nbsp;	</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <table width="738" height="244" BORDER=0 align="center">
    <tr>
      <td colspan="2" bgcolor="#000000"><div align="center" class="style2">Edit Password</div></td>
      </tr>
    <tr>
      <td width="165"><span class="style1">Old Password</span></td>
      <td width="169"><label>
      <input type="password" name="textfield" id="textfield" required>
      </label></td>
      </tr>
    <tr>
      <td><span class="style1">New Password</span></td>
      <td><input type="password" name="textfield2" id="textfield2" required></td>
      </tr>
    <tr>
      <td><span class="style1">Confirm Password</span></td>
      <td><input type="password" name="textfield3" id="textfield3" required></td>
      </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="button" id="button" value="Submit">
        <input type="reset" name="button2" id="button2" value="Reset"></td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
      </tr>
  </table>
  <div align="center"><span class="homepage"></div>
</form>

  <div align="center"></div>
</div>
<div class="categories"></div>
<table width="63%" border="0" align="center" cellpadding="10">
  <tr>
    <td width="35%">&nbsp;</td>
    <td width="51%">&nbsp;</td>
    <td width="14%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><?php
session_start();
$u=$_SESSION['user'];
//echo $u;


if (isset($_POST['button']))
{


$op=$_POST["textfield"];
$np=$_POST["textfield2"];
$cp=$_POST["textfield3"];
//echo  $op;

/////////////////
$mysqli = new mysqli("localhost", "root", "", "krushi2020");

if ($mysqli->connect_errno) 
{
	echo "Failed to connect to MySQL:".$mysqli->connect_errno;
}
$sql="select * from  user where pwd= '{$op}' and email= '{$u}'";
$found=0;
$result=$mysqli->query($sql);


if($result ->num_rows == 1)
{	
	$found=1;
}

////////////////////
if($op==null || $np==null || $cp==null)
{
	
}
else
{
if($np==$cp  && $found==1)
{


	$con = mysqli_connect("localhost", "root", "");
	mysqli_select_db($con,"krushi2020");

$query="update user set pwd='{$np}'  where email='{$u}'";

//echo $query;

mysqli_query($con,$query);

	
	
			echo("<h4>Password  Updated Successfully</h4>");
			
			
			
		
			



	
}

else
{
	echo "<h4 align=center> Some thing Wrong Please try again </h4>";
}


}

}

?></td>
    <td>&nbsp;</td>
  </tr>
</table>
<!------ featured products ------>
</body>
</html>