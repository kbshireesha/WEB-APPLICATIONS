<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style type="text/css">
<!--
.style1 {font-family: Forte}
.style2 {font-size: 24px}
.style3 {font-family: Forte; font-size: 24px; }
.style4 {font-size: 36px}
-->
</style>
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">
        </div>
        <nav>
            <ul>
                <li><span class="style1"><span class="style2"><a href="aedpwd.php"> Edit Password</a></span></span></li>
              
                <li class="style3"><a href="approved.php">Approve</a></li>
                <li class="style3"><a href="vfeed.php"> Feedback</a></li>
                <li class="style3"><a href="vorders.php"> Orders</a><br>
                 <li>  <span class="style3"><a href="index.php">signout</a></span></li>
            </ul>
        </nav>
    
</div> 
</div>
</div>
<!------ featured categories ------>
<!------ featured products ------>
<div class="small-container">
    <h2 class="title">&nbsp;</h2>
    <h2 class="title style1 style4">Welcome to Admin Page</h2>
    <p class="title"><img src="images/Copy of business-woman-table-group.jpg" width="706" height="519"></p>
    <p class="title">&nbsp;</p>
</div>
</body>
</html>