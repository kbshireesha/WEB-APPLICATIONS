<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style type="text/css">
<!--
.style1 {font-family: Forte}
.style2 {font-size: 18px}
.style3 {font-family: Forte; font-size: 18px; }
.style4 {font-family: "viner Hand ITC"}
.style5 {
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
	font-size: 24px;
	font-weight: bold;
}
.style10 {
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
	font-size: 24px;
}
.style11 {font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals"}
.style12 {font-size: 24px}
-->
</style>
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">        </div>
        <nav>
          <ul>
              <li><span class="style1"><span class="style2"><a href="edpwds.php">Edit Password</a></span></span></li>
              <li class="style3"><a href="uploadproducts.php">Upload Product</a></li>
              <li class="style3"><a href="viewapproved.php">View Approved</a></li>
              <li class="style3"><a href="products.php">Products</a></li>
              <li class="style3"><a href="index.php">signout</a></li>
            </ul>
        </nav>
      <li><span class="style3"><a href="shop.jsp"><img src="cart.PNG" width="30px" height="30px"></a></span></li>
</div> 
<div class="row">
    <div class="col-2"> 
<h1 class="style4">Buy Fresh With<br> 
  New Style!</h1>
<p>&nbsp; </p>
<a href="" class="btn style4">Explore Now &#8594;</a>    </div>
    <div class="col-2"> 
<img src="farming.jpg">
    </div>
</div>
</div>
</div>
<!------ featured categories ------>
<div class="categories">
    <div class="small-container">
        <div class="row">
            <div class="col-3">
                <h2 class="title style11 style12">FRUITS</h2>
                <img src="categories fruits.jpg">
            </div>
            <div class="style1">
                <h2 class="title style11">VEGETABLES</h2>
                <img src="categories vegetables.jpg">
          </div>
            <div class="col-3">
                <h2 class="style5">CEREALS AND PULSES</h2>
                <img src="categories cereals and pulses.jpg">
            </div>
        </div>
    </div>
   
</div>
<!------ featured products ------>
<div class="small-container">
    <h2 class="title style10"> FEATURED PRODUCTS </h2>
    <div class="row">
        <div class="col-4">
            <img src="kiwi.jpg">
            <h4>KIWI FRUIT</h4>
            <p>Rs.15 per peice</p>
        </div>
        <div class="col-4">
            <img src="grapes.jpg">
            <h4>GRAPES</h4>
            <p>Rs.45 per kg</p>
        </div>
        <div class="col-4">
            <img src="carrot.jpg">
            <h4>CARROT</h4>
            <p>Rs.25 per kg</p>
        </div>
        <div class="col-4">
            <img src="toor dal.jpg">
            <h4>TOOR DAL</h4>
            <p>Rs.98 per kg</p>
        </div>
    </div>
</div>


</body>
</html>