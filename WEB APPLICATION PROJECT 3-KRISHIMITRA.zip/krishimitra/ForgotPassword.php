<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style type="text/css">
<!--
.style1 {font-family: Forte}
.style2 {font-size: 24px}
.style3 {font-family: Forte; font-size: 24px; }
.style4 {
	font-family: Forte;
	font-size: 18px;
	font-weight: bold;
}
.style6 {font-family: Forte; font-size: 18px; }
.style7 {
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
	font-weight: bold;
	font-size: 24px;
}
-->
</style>
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">
        </div>
        <nav>    <ul>
                <li><span class="style1"><span class="style2"><a href="aboutus.php">About</a></span></span></li>
                <li class="style3"><a href="contact.php">Contact</a></li>
            <li class="style3"><a href="signin.php">signIn</a></li>
           <li> <span class="style3"><a href="signup.php">signUp</a></span></li>    
        </ul>
        </nav>
     <a href="shop.php"><img src="cart.PNG" width="30px" height="30px"></a>
</div> 
<div class="row"></div>
</div>
</div>
</div>
<!------ featured categories ------>
<div class="row"><form name="form1" method="post" action="">
  <p>&nbsp;	</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <table width="391" BORDER=0 align="center">
    <tr>
      <td colspan="3" bgcolor="#FFFFFF"><div align="center" class="style7">FORGOT PASSWORD ?</div></td>
      </tr>
    
    <tr>
      <td width="95"><span class="style6">Email Id</span></td>
      <td width="8">&nbsp;</td>
      <td width="222"><input type="text" name="textfield" id="textfield" required></td>
      </tr>
    
    <tr>
      <td colspan="3"><input type="submit" name="button" id="button" value="Reset Password">
        <a href="signin.php" class="style4">Remember Login ?  </a></td>
      </tr>
  </table>
  </form>

  <div align="center">
   
      <span class="homepage">
     <?php 
	 if (isset($_POST['button']))
{
$txt=$_POST['textfield'];
$pass=rp(strlen($txt));



///////////////////

$mysqli = new mysqli("localhost", "root", "", "krushi2020");

if ($mysqli->connect_errno) 
{
	echo "Failed to connect to MySQL:". $mysqli->connect_errno;
}


$sql="select * from  user where email ='{$txt}' ";



$found=0;
$result=$mysqli->query($sql);


if($result ->num_rows == 1)
{	
	$found=1;
}




////////////////////
if( $found==1)
{


	$con = mysqli_connect("localhost", "root", "");
	mysqli_select_db($con,"krushi2020");



$query="update user set pwd='{$pass}'  where email='{$txt}'";



//echo $query;

mysqli_query($con,$query);

	
	

			echo "<h3 align=center>Your new Password resetted successuflly  .............</h3>";
			echo "<h4> New Password is ".$pass;
			
			//echo("<h4 align=center><a href=adminhomepage.php><br>Home Page</a></h4>");
			



	
}

else
{
	echo "<h1 align=center> Some thing Wrong Please try again </h1>";
	//echo("<h4 align=center><a href=homepage.php><br>Home Page</a></h4>");
}




}




?>
  <?php 


function rp($len)
{

$chars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+;:.?";
$pass=substr( str_shuffle($chars),0,$len);
return $pass;
}


?>
  </div>
</div>
<div class="categories"></div>
<!------ featured products ------>
</body>
</html>