<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
<style>
table {
  border-collapse: collapse;
  border: 1px solid black;
} 

th,td {
  border: 1px solid black;
}

table.a {
  table-layout: auto;
  width: 180px;  
}

table.b {
  table-layout: fixed;
  width: 180px;  
}

table.c {
  table-layout: auto;
  width: 100%;  
}

table.d {
  table-layout: fixed;
  width: 100%;  
}
.style1 {
	font-family: Forte;
	font-size: 24px;
}
</style>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">
        </div>
        <nav>    <ul class="style1">
                  <li><a href="edpwds.php">Edit Password</a></li>
                <li><a href="addproduct.php">Upload or Add Product</a></li>
                <li><a href="viewapproved.php">View Approved</a></li>
                   <li><a href="index.php">signout</a></li>  </ul>
        </nav>
     
</div> 
<div class="row"></div>
</div>
</div>
</div>
<p>
  <!------ featured categories ------>
</p>
<p>&nbsp;</p>
<p align="center"><span class="feature">
  <?php



$db = new mysqli("localhost", "root", "", "krushi2020");

if ($db->connect_errno) {
echo "Failed to connect to MySQL: (" 
. $db->connect_errno . ") " . $db->connect_error;
}


$sql="select * from product"; 
//echo $sql;
$result_db = $db->query($sql) or die("Error!");
$all_result = $result_db->fetch_all();

$table =
'<table id="customers" align=center border="1";width="70%"; >
<tr>
<td>Product Id</td>
<td>Description</td>
<td>Rate</td>
<td>Photo</td>
<td>Category</td>
<td>Status</td>
</tr>';

$a="";
$b="";
$c="";
$d="";
$e="";





foreach ($all_result as $row) 
{

$a=$row[0];
$b=$row[1];
$c=$row[2];
$d=$row[3];
$e=$row[4];
$f=$row[6];
//$fi=$row[5];
	$table .= '<tr>'
	
	  . '<td>' .$a. '</td>'
  	. '<td>' . $b . '</td>'
  	. '<td>' . $c . '</td>'
	. '<td><img src=' . $d. ' width=100 height=100></img></td>'
		. '<td>' . $e . '</td>'
	. '<td>' . $f . '</td>'
//	. '<td>' ."<a href=approved1.php?a=".$a.">To Approve Click here</a>" .'</td>'
	  . '</tr>';
}




$table .='</table>';
echo $table;
	//echo("<h3 align=center><a href=admin.php>Back</a></h3>");


$db->close();

?>
</span></p>
<div class="row">
  <div align="center"></div>

</div>
<div class="categories"></div>
<!------ featured products ------>
</body>
</html>