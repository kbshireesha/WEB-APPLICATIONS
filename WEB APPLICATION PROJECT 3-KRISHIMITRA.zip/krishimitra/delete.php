<?php
$dbhost='localhost';
$dbuser='root';
$dbpass='';
$db='krushi2020';
$conn=new mysqli($dbhost,$dbuser,$dbpass,$db);
if(!$conn){
    die('could not connnect:'.mysqli_error());
}

/*if(isset($_POST['delete'])){
    */
    $n=$_GET['id'];
	
$sql="delete from carttemp where pid like '{$n}'";
echo $sql;
    $res=mysqli_query($conn,$sql);

mysqli_close($conn);
$msg="Deleted Successfully";
		echo "<script type='text/javascript'> window.alert ('$msg');</script>";
		
		echo "<h1 align=center><a href=shop.php>Shop Again</a></h1>";
//	header('Location:shop.php');
?>