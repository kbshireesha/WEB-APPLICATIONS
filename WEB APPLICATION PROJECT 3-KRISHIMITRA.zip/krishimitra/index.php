<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style type="text/css">
<!--
.style1 {font-family: "viner Hand ITC"}
.style4 {font-family: Forte}
.style8 {font-size: 10px}
.style9 {font-family: Forte; font-size: 24px; }
.style10 {font-size: 18px}
.style11 {font-size: 18}
.style12 {font-size: 24px}
.style14 {
	font-size: 36px;
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
	font-weight: bold;
}
.style15 {
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
	font-size: 24px;
}
.style16 {
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
	font-size: 18px;
}
-->
</style>
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <a href="index.php"><img src="logo.jpg" width="125px"></a>        </div>
        <nav>     <ul>
                <li><span class="style8"><span class="style10"><span class="style11"><span class="style12"><a href="aboutus.php" class="style4">About</a></span></span></span></span></li>
                <li class="style9"><a href="contact.php" class="style4">Contact</a></li>
           		 <li class="style9"><a href="signin.php">SignIn</a></li>
          		 <li class="style9"> <a href="signup.php">SignUp->Buyer</a></li>
				  <li class="style9"> <a href="signupseller.php">SignUp->Seller</a></li>
                 
       </ul>
        </nav>
        <span class="style9"><a href="shop.php"><img src="cart.PNG" width="30px" height="30px"></a></span> </div> 
<div class="row">
    <div class="col-2"> 
<h1 class="style1">Buy Fresh With New Style </h1>
<p class="style1">&nbsp;</p>
<a href="signin.php" class="btn"><span class="style16">Explore Now </span>&#8594;</a>    </div>
    <div class="col-2"> 
<img src="farming.jpg">
    </div>
</div>
</div>
</div>
  <h2 class="title  style14">CATEGORIES</h2>
  <!------ featured categories ------>
<div class="categories">
    <div class="small-container">
        <div class="row">
            <div class="col-3">
                <h2 class="style15">FRUITS</h2>
                <img src="categories fruits.jpg">
            </div>
            <div class="col-3">
                <h2 class="style15">VEGETABLES</h2>
                <img src="categories vegetables.jpg">
            </div>
            <div class="col-3">
                <h2 class="style15">CEREALS AND PULSES</h2>
                <img src="categories cereals and pulses.jpg">
            </div>
        </div>
    </div>
   
</div>
<!------ featured products ------>
<div class="small-container">
    <h2 class="title style15"> FEATURED PRODUCTS </h2>
    <div class="row">
        <div class="col-4">
            <a href="signin.php"><img src="kiwi.jpg"></a>
            <h4>KIWI FRUIT</h4>
            <p>Rs.15 per peice</p>
        </div>
        <div class="col-4">
            <a href="signin.php"><img src="grapes.jpg">
            <h4>GRAPES</h4>
            <p>Rs.45 per kg</p>
        </div>
        <div class="col-4">
            <a href="signin.php"><img src="carrot.jpg">
            <h4>CARROT</h4>
            <p>Rs.25 per kg</p>
        </div>
        <div class="col-4">
            <a href="signin.php"><img src="toor dal.jpg">
            <h4>TOOR DAL</h4>
            <p>Rs.98 per kg</p>
        </div>
    </div>
</div>


</body>
</html>