<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
.style1 {
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
	font-weight: bold;
	font-size: 24px;
}
.style2 {
	font-family: Forte;
	font-size: 18px;
}
.style3 {font-family: Forte}
.style4 {font-size: 18px}
</style>

<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">
        </div>
        <span class="style3">
        <nav>    
         </nav>
        </span> <span class="style4">
        <nav></nav>
        </span>
        <nav><ul class="style2">
          <li><a href="edpwdb.php">Edit Password</a></li>
                <li><a href="cart.php"> Cart</a></li>
                <li><a href="orderhistory.php">Order History</a></li>
                <li><a href="feedback.php">Feedback</a></li>
                <li><a href="index.php">signOut</a></li>
         </ul>
      </nav>
     
</div> 
<div class="row"></div>
</div>
</div>
</div>
  <!------ featured categories ------>
</p><div class="row">
<form name="form1" method="post" action="">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <table width="610" height="321" BORDER=0 align="center">
    <tr>
      <td height="57" colspan="2" bgcolor="#00CC99"><div align="center" class="style1">Order Acknowledgemet</div></td>
    </tr>
    <tr>
      <td width="216"><span class="style2">Invoice no</span></td>
      <td width="233"><input type="text" name="textfield" id="textfield" value="<?php 	$mysqli= new mysqli("localhost", "root", "", "krushi2020");

if ($mysqli->connect_errno) 
{
	echo "Failed to connect to MySQL: (". $db->connect_errno . ") " . $db->connect_error;
}



$sql="select * from  payment2";
$result=$mysqli->query($sql);


$cnt=$result->num_rows ;
$cnt=$cnt+1001;
$cnt="O-".$cnt;
//setcookie("pac",$cnt);
echo $cnt;
		   ?>"></td>
    </tr>
    <tr>
      <td> <span class="style2">Invoice Date</span></td>
      <td><label>
        <input type="text" name="textfield2" id="textfield2" value="<?php $doi=date("Y/m/d"); echo $doi; ?>">
      </label></td>
    </tr>
    <tr>
      <td><span class="style2">Total Amount</span></td>
      <td><input type="text" name="textfield3" id="textfield3" value="<?php $amt=$_GET["amt"]; echo $amt;?>"></td>
    </tr>
    <tr>
      <td><span class="style2">Email id</span></td>
      <td><input type="text" name="textfield4" id="textfield4" value="<?php 	session_start();  $e=$_SESSION["user"]; echo $e;  ?>"></td>
    </tr>
    <tr>
      <td><span class="style2">Full Name</span></td>
      <td><input type="text" name="textfield7" id="textfield7" value="<?php 	  $n=$_SESSION["n"]; echo $n;  ?>"></td>
    </tr>
    <tr>
      <td><span class="style2">Address</span></td>
      <td><input type="text" name="textfield5" id="textfield5"></td>
    </tr>
    <tr>
      <td><span class="style2">Mobile</span></td>
      <td><input type="text" name="textfield6" id="textfield6" value="<?php 	 $m=$_SESSION["m"]; echo $m;  ?>"></td>
    </tr>
    <tr>
      <td><span class="style2">Status</span></td>
      <td><input name="textfield8" type="text" id="textfield8" value="Ordered" readonly></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="button" id="button" value="Submit">
          <input type="reset" name="button2" id="button2" value="Reset"></td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
<table width="100%" border="0" align="center" cellpadding="10">
  <tr>
    <td width="18%" height="51">&nbsp;</td>
    <td width="65%"><?php include "dbcon.php" ?>
      <?php 

if (isset($_POST['button']))
{

$a=$_POST["textfield"];
$b=$_POST["textfield2"];
$c=$_POST["textfield3"];
$d=$_POST["textfield4"];
$e=$_POST["textfield7"];
$f=$_POST["textfield5"];
$g=$_POST["textfield6"];
$h=$_POST["textfield8"];



$query = "insert into payment2  values('$a','$b','$c','$d','$e','$f','$g','$h')";
//echo $query;
mysqli_query($con,$query);

echo "<h3 align = center>Order placed successfully </h3>";
$query = "delete from carttemp";
//echo $query;
mysqli_query($con,$query);

}

?></td>
    <td width="17%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<p align="center">&nbsp;</p>
<div class="row">
  <div align="center"></div>

</div>
<div class="categories"></div>
<!------ featured products ------>
</body>
</html>