<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
.style1 {
	color: #FFFFFF;
	font-weight: bold;
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
}
.style2 {
	font-family: Forte;
	font-size: 24px;
}
.style3 {font-family: Forte}
</style>

<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">
        </div>
        <nav>    <ul class="style2">
                  <li><a href="aedpwd.php"> Edit Password</a></li>
              
                <li><a href="approved.php">Approve</a></li>
                <li><a href="vfeed.php"> Feedback</a></li>
                <li><a href="vorders.php"> Orders</a><br>
          <li>  <a href="index.php">signout</a></li>     </ul>
        </nav>
     
</div> 
<div class="row"></div>
</div>
</div>
</div>
<p>
  <!------ featured categories ------>
</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div class="row">
<form name="form1" method="post" action="">
  <table width="540" height="270" BORDER=0 align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td width="153" bgcolor="#000000">&nbsp;</td>
      <td width="216" bgcolor="#000000"><span class="style1">Add Product</span></td>
      <td width="318" colspan="2" rowspan="4">&nbsp;</td>
    </tr>
    <tr>
      <td><span class="style3">Product Id</span></td>
      <td><input type="text" name="textfield" id="textfield" value="<?php 	$id=$_GET['a']; echo $id;	   ?>"></td>
    </tr>
    
    <tr>
      <td><span class="style3">Status Update</span></td>
      <td><select name="select" id="select">
        <option value="Approve">Approve</option>
        <option value="DisApprove">DisApprove</option>
            </select></td>
    </tr>
    
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="button" id="button" value="Update ">
          <input type="reset" name="button2" id="button2" value="Reset"></td>
    </tr>
  </table>
</form>

<table width="100%" border="0" cellpadding="10" style="border:none;" >
  <tr>
    <td width="41%">&nbsp;</td>
    <td width="33%"><?php
////session_start();
//$u=$_SESSION['user'];
//echo $u;


if (isset($_POST['button']))
{


$id=$_POST["textfield"];
$st=$_POST["select"];

/////////////////
$mysqli= new mysqli("localhost", "root", "", "krushi2020");

if ($mysqli->connect_errno) 
{
	echo "Failed to connect to MySQL: (". $db->connect_errno . ") " . $db->connect_error;
}

	$con = mysqli_connect("localhost", "root", "");
	mysqli_select_db($con,"krushi2020");

$query="update product set status='Approved'  where pid='{$id}'";


mysqli_query($con,$query);

	
	
			echo(" Updated Successfully");
			
			
			
			//cho("<h4 align=center><a href=facultyhomepage.php><br>Home Page</a></h4>");
			



	

}




?></td>
    <td width="26%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<p align="center">&nbsp;</p>
<div class="row">
  <div align="center"></div>

</div>
<div class="categories"></div>
<!------ featured products ------>
</body>
</html>