<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
<style>
table {
  border-collapse: collapse;
  border: 1px solid black;
} 

th,td {
  border: 1px solid black;
}

table.a {
  table-layout: auto;
  width: 180px;  
}

table.b {
  table-layout: fixed;
  width: 180px;  
}

table.c {
  table-layout: auto;
  width: 100%;  
}

table.d {
  table-layout: fixed;
  width: 100%;  
}
.style1 {font-family: Forte}
.style2 {font-size: 24px}
.style3 {font-family: Forte; font-size: 24px; }
</style>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">        </div>
       <nav>    
       <ul>
                   <li><span class="style1"><span class="style2"><a href="aedpwd.php"> Edit Password</a></span></span></li>
              
                <li class="style3"><a href="approved.php">Approve</a></li>
                <li class="style3"><a href="vfeed.php"> Feedback</a></li>
                <li class="style3"><a href="vorders.php"> Orders</a><br>
                 <li class="style3">  <a href="index.php">signout</a></li>
            </ul>
        </nav>
</div> 
<div class="row style1 style2"></div>
</div>
</div>
</div>
<p>
  <!------ featured categories ------>
</p>
<p>&nbsp;</p>
<p align="center"><span class="feature">
 <?php include "dbcon.php" ?>
  <?php

//session_start();
//$u=$_SESSION['user'];


$db = new mysqli("localhost", "root", "", "krushi2020");

if ($db->connect_errno) {
echo "Failed to connect to MySQL: (" 
. $db->connect_errno . ") " . $db->connect_error;
}
echo "<h1 align=center> Order History</h1>";

$sql="select * from payment2";// where emailid='{$u}' "; 
//echo $sql;
$result_db = $db->query($sql) or die("Error!");
$all_result = $result_db->fetch_all();

$table =
'<table id="customers" align=center border="1";width="70%"; >
<tr>
<td>Invoice No</td>
<td>Invoice Date</td>
<td>Amount</td>
<td>Email id</td>
<td>Full Name</td>
<td>Shipping Address</td>
<td>Status</td>

</tr>';

$a="";
$b="";
$c="";
$d="";
$e="";
$f="";
$g="";
$h="";


$count=0;
//$sum=0;
foreach ($all_result as $row) 
{
$count++;
$a=$row[0];
$b=$row[1];
$c=$row[2];
$d=$row[3];
$e=$row[4];
$f=$row[5];
$g=$row[6];
$h=$row[7];
//$sum=$sum+$c;
//$f=$row[6];
//$fi=$row[5];
	$table .= '<tr>'
	
	  . '<td>' .$a. '</td>'
  	. '<td>' . $b . '</td>'
  	. '<td>' . $c . '</td>'
	. '<td>' . $e . '</td>'
	. '<td>' . $f . '</td>'
	. '<td>' . $g . '</td>'
	. '<td>' . $h . '</td>'
	
	
	  . '</tr>';


}


$table .='</table>';
echo $table;
if($count==0)
	echo("<h3 align=center>No Items in the cart yet....</h3>");
else
/*echo("<h3 align=center>Total value of the Cart ....Rs.".$sum."</h3>");
echo("<h3 align=center>Total Items in the Cart ....".$count."</h3>");
echo("<h3 align=center><a href=confirm.php?amt=".$sum.">Confirm Order</a></h3>");*/
$db->close();
?>
</span></p>
<div class="row">
  <div align="center"></div>
</div>
<div class="categories"></div>
<!------ featured products ------>
</body>
</html>