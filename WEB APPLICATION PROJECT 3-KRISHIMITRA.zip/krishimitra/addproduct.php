<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style type="text/css">
<!--
.style1 {
	font-family: Forte;
	font-size: 24px;
}
.style2 {font-family: Forte}
.style4 {
	color: #FFFFFF;
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
	font-weight: bold;
}
-->
</style>
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">
        </div>
        <nav>    <ul class="style1">
                 <li><a href="edpwds.php">Edit Password</a></li>
                <li><a href="addproduct.php">Upload or Add Product</a></li>
                <li><a href="viewapproved.php">View Approved</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="index.php">signout</a></li> </ul>
        </nav>
   
</div> 
<div class="row"></div>
</div>
</div>
</div>
<!------ featured categories ------>
<div class="row"><form name="form1" method="post" action="">
  <p>&nbsp;	</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <table width="699" height="279" BORDER=0 align="center">
    <tr>
      <td colspan="2" bgcolor="#000000"><div align="center" class="style4">ADD PRODUCT </div></td>
      </tr>
    <tr>
      <td width="153"><span class="style2">Product Id</span></td>
      <td width="216"><input type="text" name="textfield" id="textfield" value="<?php 	$mysqli= new mysqli("localhost", "root", "", "krushi2020");

if ($mysqli->connect_errno) 
{
	echo "Failed to connect to MySQL: (". $db->connect_errno . ") " . $db->connect_error;
}



$sql="select * from  product";
$result=$mysqli->query($sql);


$cnt=$result->num_rows ;
$cnt=$cnt+1001;
$cnt="Ac-".$cnt;
//setcookie("pac",$cnt);
echo $cnt;
		   ?>"></td>
      </tr>
    <tr>
      <td><span class="style2"> Product Description</span></td>
      <td><label>
        <input type="text" name="textfield2" id="textfield2">
      </label></td>
      </tr>
    <tr>
      <td><span class="style2">Rate</span></td>
      <td><input type="text" name="textfield3" id="textfield3"></td>
      </tr>
    
    <tr>
      <td><span class="style2">Photo</span></td>
      <td><input type="file" name="textfield4" id="textfield4"></td>
      </tr>
    <tr>
      <td><span class="style2">Category</span></td>
      <td><select name="select" id="select">
        <option value="Fruit">Fruit</option>
        <option value="Vegetable">Vegetable</option>
        <option value="Cereals and Pulses">Cereals and Pulses</option>
        </select></td>
      </tr>
    <tr>
      <td><span class="style2">GST (%)</span></td>
      <td><input name="textfield5" type="text" id="textfield5" value="3%"></td>
      </tr>
    
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="button" id="button" value="Submit">
          <input type="reset" name="button2" id="button2" value="Reset"></td>
      </tr>
  </table>
  </form>
  <div align="center"></div>

</div>
<div class="categories"></div>
<table width="100%" border="0" cellpadding="10">
  <tr>
    <td width="28%">&nbsp;</td>
    <td width="55%"><?php include "dbcon.php" ?>
        <?php 

if (isset($_POST['button']))
{

$a=$_POST["textfield"];
$b=$_POST["textfield2"];
$c=$_POST["textfield3"];
$d=$_POST["textfield4"];
$e=$_POST["select"];
$f=$_POST["textfield5"];



/*$sql="select * from user where  email='{$f}'";
$found=0;
$result=$con->query($sql);
if($result ->num_rows == 1)
{	
	$found=1;
}
	
	if($found==0)
	{*/

$query = "insert into product  values('$a','$b','$c','$d','$e','$f','Pending')";
//echo $query;
mysqli_query($con,$query);

echo "<h3 align = center>Uploaded successfully </h3>";
/*}
else
{
		echo("<h4 align=center>Sorry ,User already Registered...</h4>");		
}
*/
}
?></td>
    <td width="17%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<!------ featured products ------>
</body>
</html>