<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style type="text/css">
<!--
.style7 {
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
	font-size: 24px;
}
.style8 {color: #000000}
.style9 {font-family: Forte}
.style10 {font-size: 18px}
.style11 {font-family: Forte; font-size: 24px; }
-->
</style>
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">
        </div>
        <span class="style9">
        <nav>
        </nav>
        </span> <span class="style10">
        <nav></nav>
        </span>
        <nav><ul class="style11">
            <li><a href="edpwds.php">Edit Password</a></li>
            <li><a href="addproduct.php">Upload or Add Product</a></li>
            <li><a href="viewapproved.php">View Approved</a></li>
              
            <li><a href="index.php">signout</a></li>
            </ul>
        </nav>
     
</div> 
</div>
</div>
<!------ featured categories ------>
<!------ featured products ------>
<div>
    <table width="100%" border="0" align="center" cellpadding="10">
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td width="28%">&nbsp;</td>
        <td width="42%"><div align="center" class="style7"><span class="title style8">WELCOME TO SELLER PAGE</span></span></span></div></td>
        <td width="30%">&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table>
</div>
</body>
</html>