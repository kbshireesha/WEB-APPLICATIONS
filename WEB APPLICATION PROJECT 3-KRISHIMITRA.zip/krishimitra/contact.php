<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style type="text/css">
<!--
.style4 {font-family: Forte}
.style9 {font-family: Forte; font-size: 24px; }
.style12 {font-size: 24px}
.style14 {font-family: Forte; font-size: 16px; }
-->
</style>
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <a href="index.php"><img src="logo.jpg" width="125px"></a>        </div>
        <nav>     <ul class="style12">
                <li><a href="aboutus.php" class="style4">About</a></li>
                <li class="style4"><a href="contact.php" class="style4">Contact</a></li>
           		 <li class="style4"><a href="signin.php">SignIn</a></li>
          		 <li class="style4"> <a href="signup.php">SignUp->Buyer</a></li>
				  <li class="style4"> <a href="signupseller.php">SignUp->Seller</a></li>    </ul>
        </nav>
      <a href="shop.php"><img src="cart.PNG" width="30px" height="30px"></a>
</div> 
<div class="row">
    <div class="col-2"> 
      <div>
        <div>
          <div>
            <div>
              <div>
                <h2 class="style9">Get in touch with us from the below Details....</h2>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="contact">
        <div>
          <div>
            <div>
              <div>
                <div>
                  <h3 class="style9">Address</h3>
                  <span class="style14">Bangaloe,Karnataka                  </span>
                  <p class="style14">(+91)**********<br>
                    krishimithra@gmail.com</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <br>
      <h1>&nbsp;</h1>
</div>
    </div>
</div>
</div>
<!------ featured categories ------>
<div class="categories">
  <div class="small-container"></div>
   
</div>
<!------ featured products ------>
</body>
</html>