<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style type="text/css">
<!--
.style1 {
	font-family: Forte;
	font-size: 24px;
}
.style2 {font-size: 24px}
.style3 {
	font-family: Forte;
	font-size: 36px;
	font-weight: bold;
}
-->
</style>
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">
        </div>
        <nav>
            <ul>
                <li class="style1"><a href="edpwdb.php">Edit Password</a></li>
                <li class="style1"><a href="cart.php"> Cart</a></li>
                <li class="style1"><a href="orderhistory.php">Order History</a></li>
                <li class="style1"><a href="feedback.php">Feedback</a></li>
                <li><span class="style1"><a href="index.php">signou</a></span><span class="style2"><a href="index.php"></a></span><a href="index.php">t</a></li>
            </ul>
        </nav>
     
</div> 
<div class="row">
  <div class="col-2"></div>
</div>
</div>
</div>
<!------ featured categories ------>
<!------ featured products ------>
<div>
    
    <h2 align="center">&nbsp;</h2>
    <p align="center">&nbsp;</p>
    <p align="center" class="style3">WELCOME TO BUYER PAGE </p>
</div>
</body>
</html>