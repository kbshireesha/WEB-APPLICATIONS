<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style type="text/css">
<!--
.style1 {
	font-family: Forte;
	font-size: 24px;
}
.style2 {font-family: Forte}
.style4 {
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
	color: #FFFFFF;
}
-->
</style>
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">
        </div>
        <nav>    
        <ul class="style1">  <li><a href="edpwds.php">Edit Password</a></li>
                <li><a href="addproduct.php">Upload or Add Product</a></li>
                <li><a href="viewapproved.php">View Approved</a></li>
              
                <li><a href="index.php">signout</a>
          </ul>
        </nav>
     
</div> 
<div class="row"></div>
</div>
</div>
</div>
<!------ featured categories ------>
<div class="row"><form name="form1" method="post" action="">
  <p>&nbsp;	</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <table width="683" BORDER=0 align="center">
    <tr>
      <td width="95" bgcolor="#000000">&nbsp;</td>
      <td width="222" bgcolor="#000000"><span class="style4">EDIT PASSWORD </span></td>
      </tr>
    <tr>
      <td><span class="style2">Old Password</span></td>
      <td><label>
      <input type="text" name="textfield" id="textfield">
      </label></td>
      </tr>
    <tr>
      <td><span class="style2">New Password</span></td>
      <td><input type="text" name="textfield2" id="textfield2"></td>
      </tr>
    <tr>
      <td><span class="style2">Confirm Password</span></td>
      <td><input type="text" name="textfield3" id="textfield3"></td>
      </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="button" id="button" value="Submit">
          <input type="reset" name="button2" id="button2" value="Reset"></td>
      </tr>
  </table>
  <div align="center"><span class="homepage"></div>
</form>

  <div align="center"></div>
</div>
<div class="categories"></div>
<table width="50%" border="0" align="center">
  <tr>
    <td width="24%">&nbsp;</td>
    <td width="52%"><?php
session_start();
$u=$_SESSION['user'];
//echo $u;


if (isset($_POST['button']))
{


$op=$_POST["textfield"];
$np=$_POST["textfield2"];
$cp=$_POST["textfield3"];
//echo  $op;

/////////////////
$db = new mysqli("localhost", "root", "", "krushi2020");

if ($db->connect_errno) 
{
	echo "Failed to connect to MySQL: (". $db->connect_errno . ") " . $db->connect_error;
}
$sql="select * from  seller where pwd= '{$op}' and email= '{$u}'";
//echo $sql;
$found=0;
$result=$db->query($sql);


if($result ->num_rows == 1)
{	
	$found=1;
}

////////////////////
if($op==null || $np==null || $cp==null)
{
	
}
else
{
if($np==$cp  && $found==1)
{


	$con = mysqli_connect("localhost", "root", "");
	mysqli_select_db($con,"krushi2020");

$query="update seller set pwd='{$np}'  where email='{$u}'";

//echo $query;

mysqli_query($con,$query);

	
	
			echo("Password  Updated Successfully");
			
			
			
			//cho("<h4 align=center><a href=facultyhomepage.php><br>Home Page</a></h4>");
			



	
}

else
{
	echo "<h4 align=center> Some thing Wrong Please try again </h4>";
}
}


}

?></td>
    <td width="24%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<!------ featured products ------>
</body>
</html>