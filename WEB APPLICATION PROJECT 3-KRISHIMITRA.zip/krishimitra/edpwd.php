<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">
        </div>
        <nav>
            <ul>
                <li><a href="edpwd.php">Edit Password</a></li>
                <li><a href="addproduct.php">Add Product</a></li>
                <li><a href="approved.php">Approved</a></li>
                <li><a href="vfeed.php">View Feedback</a></li>
                <li><a href="vorders.php">View Orders</a><br>
                  <a href="index.php">signout</a></li>
            </ul>
        </nav>
      <li><a href="shop.jsp"><img src="cart.PNG" width="30px" height="30px"></a></li>
</div> 
<div class="row">
    <div class="col-2"> 
<h1>Buy Fresh Without <br> New Style!</h1>
<p>Keep as near as ever you can to the first source<br> of supply fruits and vegetables.</p>
<a href="" class="btn">Explore Now &#8594;</a>
    </div>
    <div class="col-2"> 
<img src="farming.jpg">
    </div>
</div>
</div>
</div>
<!------ featured categories ------>
<div class="categories">
    <div class="small-container">
        <div class="row">
            <div class="col-3">
                <h2>FRUITS</h2>
                <img src="categories fruits.jpg">
            </div>
            <div class="col-3">
                <h2>VEGETABLES</h2>
                <img src="categories vegetables.jpg">
            </div>
            <div class="col-3">
                <h2>CEREALS AND PULSES</h2>
                <img src="categories cereals and pulses.jpg">
            </div>
        </div>
    </div>
   
</div>
<!------ featured products ------>
<div class="small-container">
    <h2 class="title">Featured Products</h2>
    <div class="row">
        <div class="col-4">
            <img src="kiwi.jpg">
            <h4>KIWI FRUIT</h4>
            <p>Rs.15 per peice</p>
        </div>
        <div class="col-4">
            <img src="grapes.jpg">
            <h4>GRAPES</h4>
            <p>Rs.45 per kg</p>
        </div>
        <div class="col-4">
            <img src="carrot.jpg">
            <h4>CARROT</h4>
            <p>Rs.25 per kg</p>
        </div>
        <div class="col-4">
            <img src="toor dal.jpg">
            <h4>TOOR DAL</h4>
            <p>Rs.98 per kg</p>
        </div>
    </div>
</div>


</body>
</html>