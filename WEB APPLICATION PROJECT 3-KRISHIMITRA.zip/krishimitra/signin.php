<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style type="text/css">
<!--
.style9 {
	color: #FFFFFF;
	font-weight: bold;
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
	font-size: 18px;
}
.style14 {font-family: Forte; font-size: 18px;}
.style16 {font-family: Forte}
.style18 {font-size: 14px; font-family: Forte; color: #000000;}
.style19 {font-size: 14px; color: #000000;}
.style20 {font-size: 18px}
.style21 {font-size: 24px}
.style22 {font-family: Forte; font-size: 24px; }
.style23 {font-size: 24}
-->
</style>
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">        </div>
        <nav>    <ul>
                 <li><span class="style20"><span class="style16"><span class="style21"><span class="style23"><span class="style21"><a href="aboutus.php">About</a></span></span></span></span></span></li>
                <li class="style22"><a href="contact.php">Contact</a></li>
           		 <li class="style22"><a href="signin.php">SignIn</a></li>
          		 <li class="style22"> <a href="signup.php">SignUp->Buyer</a></li>
				  <li class="style22"> <a href="signupseller.php">SignUp->Seller</a></li>
        </ul>
        </nav>
        <span class="style22"><a href="shop.php"><img src="cart.PNG" width="30px" height="30px"></a></span><span class="style21">        </span></div> 
<div class="row"></div>
</div>
</div>
</div>
<!------ featured categories ------>
<div class="row">
 
    <form name="form1" method="post" action="signinnew.php"> 
      <table width="594" height="250" BORDER=0 align="center" cellpadding="10">
        <tr>
          <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td colspan="2" bgcolor="#000000"><div align="center" class="style9">SIGN IN </div></td>
        </tr>
        <tr>
          <td width="185" bgcolor="#FFFFFF"><div align="center" class="style14">Login As</div></td>
          <td width="363" bordercolor="#000000"><label>
            <div align="center">
              <select name="select" id="select">
                <option value="Admin">Admin</option>
                <option value="Seller">Seller</option>
                <option value="Buyer">Buyer</option>
              </select>
              </div>
          </label></td>
        </tr>
        <tr>
          <td><div align="center" class="style14">User Name</div></td>
          <td>
            <div align="center">
              <input type="text" name="textfield" id="textfield"required>
            </div></td>
        </tr>
        <tr>
          <td><div align="center" class="style14">Password</div></td>
          <td>
            
            <div align="center">
              <input type="password" name="textfield2" id="textfield2" required>
              </div></td></tr>
        <tr>
          <td height="47"><div align="center"></div></td>
          <td>
            
             <div align="center" class="style14">
               <input type="submit" name="button" id="button" value="Submit">
               <input type="reset" name="button2" id="button2" value="Reset">
             </div></td>
        </tr>
        <tr>
          <td height="84" colspan="2"><p align="center" class="style16"><a href="ForgotPassword.php" class="style19">Forgot Password?</a></p>
              <p align="center"><a href="signup.php" class="style18">No Account? Signup as Buyer</a></p>
			  <p align="center"><a href="signupseller.php" class="style18">No Account? Signup as Seller</a></p></td>
        </tr>
      </table>
  </form>
  <div align="center"></div>
  
</div><div class="categories"></div>
<table width="62%" border="0" align="center" cellpadding="10">
  <tr>
    <td width="17%">&nbsp;</td>
    <td width="58%"></td>
    <td width="25%">&nbsp;</td>
  </tr>
</table>
<!------ featured products ------>
</body>
</html>