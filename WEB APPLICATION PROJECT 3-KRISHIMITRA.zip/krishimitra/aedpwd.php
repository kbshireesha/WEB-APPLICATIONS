<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style type="text/css">
<!--
.style1 {
	font-family: Forte;
	font-size: 24px;
}
.style2 {font-family: Forte}
.style4 {
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
	color: #FFFFFF;
	font-weight: bold;
	font-size: 18px;
}
-->
</style>
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">
        </div>
        <nav>    
               <ul class="style1">
                  <li><a href="aedpwd.php"> Edit Password</a></li>
              
                <li><a href="approved.php">Approve</a></li>
                <li><a href="vfeed.php"> Feedback</a></li>
                <li><a href="vorders.php"> Orders</a><br>
                 <li>  <a href="index.php">signout</a></li>
            </ul>
        </nav>
     
</div> 
<div class="row"></div>
</div>
</div>
</div>
<!------ featured categories ------>
<div class="row"><form name="form1" method="post" action="">
  <p>&nbsp;	</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <table width="512" height="291" BORDER=0 align="center" cellpadding="10">
    <tr>
      <td colspan="3" bgcolor="#000000"><div align="center" class="style4">EDIT PASSWORD </div></td>
      </tr>
    <tr>
      <td width="173"><span class="style2">Old Password</span></td>
      <td width="12">&nbsp;</td>
      <td width="142"><label>
      <input type="password" name="textfield" id="textfield" required>
      </label></td>
      </tr>
    <tr>
      <td><span class="style2">New Password</span></td>
      <td>&nbsp;</td>
      <td><input type="password" name="textfield2" id="textfield72" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required="required"/></td>
      </tr>
    <tr>
      <td><span class="style2">Confirm Password</span></td>
      <td>&nbsp;</td>
      <td><input type="password" name="textfield3" id="textfield2" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required="required"/></td>
      </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><input type="submit" name="button" id="button" value="Submit">
          <input type="reset" name="button2" id="button2" value="Reset"></td>
      </tr>
  </table>
 
</form>

  <p align="center">&nbsp;</p>
</div>
<div class="categories">
  <table width="100%" border="0" cellpadding="10">
    <tr>
      <td width="32%">&nbsp;</td>
      <td width="42%"><?php
session_start();
$u=$_SESSION['user'];
//echo $u;


if (isset($_POST['button']))
{


					$op=$_POST["textfield"];
					$np=$_POST["textfield2"];
					$cp=$_POST["textfield3"];
					//echo  $op;
					
					/////////////////
					$mysqli= new mysqli("localhost", "root", "", "krushi2020");
					
					if ($mysqli->connect_errno) 
					{
						echo "Failed to connect to MySQL:".$mysqli->connect_errno;
					}
$sql="select * from  admin where p= '{$op}' and u= '{$u}'";
//echo $sql;
$found=0;
$result=$mysqli->query($sql);


if($result ->num_rows == 1)
{	
	$found=1;
}

////////////////////
if($op==null || $np==null || $cp==null)
{
	
}
else
{
if($np==$cp  && $found==1)
{


	$con = mysqli_connect("localhost", "root", "");
	mysqli_select_db($con,"krushi2020");

$query="update admin set p='{$np}'  where u='{$u}'";

//echo $query;

mysqli_query($con,$query);

	
	
			echo("<h1>Password  Updated Successfully<h1>");
			
			
			
			
			



}

else
{
	echo "<h4 align=center> Some thing Wrong Please try again </h4>";
}
}


}

?>
        <div align="center"></div>
      <div align="center"></div></td>
      <td width="26%">&nbsp;</td>
    </tr>
  </table>
</div>
<!------ featured products ------>
</body>
</html>