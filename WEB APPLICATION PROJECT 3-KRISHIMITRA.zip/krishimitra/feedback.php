<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
     <link href="stylenew.css" rel="stylesheet">
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style type="text/css">
<!--
.style8 {font-size: 12px}
.style9 {color: #006633}
.style10 {font-family: Forte}
.style11 {font-size: 24px}
.style12 {font-family: Forte; font-size: 24px; }
-->
</style>
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">        </div>
        <nav>
          <ul>
            <li><span class="style10"><span class="style11"><a href="edpwdb.php">Edit Password</a></span></span></li>
              <li class="style12"><a href="cart.php"> Cart</a></li>
              <li class="style12"><a href="orderhistory.php">Order History</a></li>
              <li class="style12"><a href="feedback.php">Feedback</a></li>
              <li class="style12"><a href="index.php">signout</a></li>
            </ul>
        </nav>
        <span class="style12"><a href="shop.php"><img src="cart.PNG" width="30px" height="30px"></a></span></div>
</div>
</div>
<!------ featured categories ------>
<!------ featured products ------>
<div class="small-container">
    <h2 class="title">&nbsp;</h2>
    <form name="form1" method="post" action="">
      <table width="693" border="0" align="center">
        <tr>
          <td>&nbsp;</td>
          <td><span class="title style9"><strong>Feed back</strong></span></td>
          <td width="457" rowspan="5"><img src="images/Network-and-computer-system-administrator.png" width="198" height="156"></td>
        </tr>
        <tr>
          <td width="226"><div align="center"><span class="style8">Full Name </span></div></td>
          <td width="457"><label></label>
            <input type="text" name="textfield7" id="textfield7" value="<?php 	 session_start(); $n=$_SESSION["n"]; echo $n;  ?>" readonly="readonly"></td>
        </tr>
        <tr>
          <td height="28"><div align="center"><span class="style8">Feedback</span></div></td>
          <td><label>
            <input type="text" name="feedback" required="required" />
          </label></td>
        </tr>
        <tr>
          <td><div align="center"><span class="style8">Phone No </span></div></td>
          <td><label>
          <input type="text" name="textfield6" id="textfield6" value="<?php 	 $m=$_SESSION["m"]; echo $m;  ?>" readonly="readonly">
          </label></td>
        </tr>
        <tr>
          <td><div align="center"><span class="style8">E-Mail</span></div></td>
          <td><input type="text" name="textfield4" id="textfield4" value="<?php 	  $e=$_SESSION["user"]; echo $e;  ?>" readonly="readonly"></td>
        </tr>
        <tr>
          <td colspan="3"><div align="center">Rate This </div>
              <div class="stars">
                <input name="star" type="radio" class="star-1" id="star-6" value="1" />
                <label class="star-1" for="star-6">1</label>
                <input name="star" type="radio" class="star-2" id="star-7" value="2" />
                <label class="star-2" for="star-7">2</label>
                <input name="star" type="radio" class="star-3" id="star-8" value="3" />
                <label class="star-3" for="star-8">3</label>
                <input name="star" type="radio" class="star-4" id="star-9" value="4" />
                <label class="star-4" for="star-9">4</label>
                <input name="star" type="radio" class="star-5" id="star-10" value="5" />
                <label class="star-5" for="star-10">5</label>
                <span></span> </div>                       </td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><div align="left">
              <input type="submit" name="Submit" value="Submit" />
              <input type="reset" name="Submit3" value="Reset" />
          </div></td>
          <td>&nbsp;</td>
        </tr>
      </table>
  </form>
    <p class="title"> <?php include "dbcon.php" ?>
  <?php 

if (isset($_POST['Submit']))
{

$a=$_POST["textfield7"];
$b=$_POST["feedback"];
$c=$_POST["textfield6"];
$d=$_POST["textfield4"];

$e=$_POST["star"];




$query = "insert into feedback  values('$a','$b','$c','$d','$e')";
//echo $query;
mysqli_query($con,$query);

echo "<h3 align = center>Feedback successfull </h3>";

}

?>&nbsp;</p>
    <p class="title">&nbsp;</p>
</div>
</body>
</html>