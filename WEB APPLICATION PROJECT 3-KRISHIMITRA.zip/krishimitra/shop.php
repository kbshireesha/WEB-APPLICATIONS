<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ಕೃಷಿ ಮಿತ್ರ | AGROMER</title>
    <link rel="stylesheet"
href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
<style>
table {
  border-collapse: collapse;
  border: 1px solid black;
} 

th,td {
  border: 1px solid black;
}

table.a {
  table-layout: auto;
  width: 180px;  
}

table.b {
  table-layout: fixed;
  width: 180px;  
}

table.c {
  table-layout: auto;
  width: 100%;  
}

table.d {
  table-layout: fixed;
  width: 100%;  
}
.style1 {font-family: Forte}
.style2 {font-size: 24px}
.style3 {font-family: Forte; font-size: 24px; }
.style5 {font-family: Forte; font-size: 18px; }
.style6 {font-size: 18px}
.style7 {
	font-family: "Monotype Corsiva", "Viner Hand ITC", "Eras Bold ITC", "Lucida Calligraphy", "Matura MT Script Capitals";
	font-weight: bold;
	font-size: 24px;
	color: #FFFFFF;
}
</style>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
            <img src="logo.jpg" width="125px">        </div>
        <nav>    
        <ul>
                <li><span class="style1"><span class="style2"><a href="aboutus.php">About</a></span></span></li>
                <li class="style3"><a href="contact.php">Contact</a></li>
           		 <li class="style3"><a href="signin.php">SignIn</a></li>
          		 <li class="style3"> <a href="signup.php">SignUp->Buyer</a></li>
				  <li class="style3"> <a href="signupseller.php">SignUp->Seller</a></li>
       </ul>
        </nav>
        <span class="style3"><a href="shop.php"><img src="cart.PNG" width="30px" height="30px"></a></span><span class="style1">        </span></div> 

</div>
</div>
</div>

<form name="form1" method="post" action="">
  <div align="center">
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <table width="525" height="195" BORDER=0 align="center" cellpadding="10">
      <tr>
        <td width="446" bgcolor="#000000"><div align="center" class="style7">SHOP</div></td>
      </tr>
      
      <tr>
        <td><label>
          <div align="center">
            <input type="radio" name="radio" id="radio" value="Fruit">
            <span class="style5">Frui</span><span class="style1">t 
            </span>
            <input type="radio" name="radio" id="radio" value="Vegetable">
            <span class="style5">
            Vegetables 
            <label>
            <input type="radio" name="radio" id="radio2" value="Cereals and Pulses">
            </label>
            </span>
            <span class="style6">
            <label><span class="style1">            Cereals and Pulses</span></label>
            </span>
          </div>
        </label></td>
      </tr>
      <tr>
        <td><div align="center">
          <input type="submit" name="button" id="button" value="Search">
        </div></td>
      </tr>
    </table>
  </div>
</form>


<div class="categories"></div>
<div align="center"><span class="feature">
  <?php


if (isset($_POST['button']))
{
$a=$_POST["radio"];

$db = new mysqli("localhost", "root", "", "krushi2020");

if ($db->connect_errno) {
echo "Failed to connect to MySQL:".$db->connect_error;
}


$sql="select * from product where category='{$a}' and status='Approved'"; 
//echo $sql;
$result_db = $db->query($sql) or die("Error!");
$all_result = $result_db->fetch_all();

$table =
'<table id="customers" align=center border="1";width="70%"; >
<tr>
<td>Product Id</td>
<td>Description</td>
<td>Rate</td>
<td>Photo</td>
<td>Category</td>

</tr>';

$a="";
$b="";
$c="";
$d="";
$e="";





foreach ($all_result as $row) 
{

$a=$row[0];
$b=$row[1];
$c=$row[2];
$d=$row[3];
$e=$row[4];
//$f=$row[6];
//$fi=$row[5];
	$table .= '<tr>'
	
	  . '<td>' .$a. '</td>'
  	. '<td>' . $b . '</td>'
  	. '<td>' . $c . '</td>'
	. '<td><img src='.$d.' width=100 height=100></img></td>'
		. '<td>' . $e . '</td>'
	//. '<td>' . $f . '</td>'
	. '<td>' .'<a href=addtocart.php?a='.$a.'&b='.$b.'&c='.$c.'&d='.$d.'&e='.$e.'><img src=cart.PNG width=30px height=30px></a>' .'</td>'
	  . '</tr>';
}




$table .='</table>';
echo $table;
	//echo("<h3 align=center><a href=admin.php>Back</a></h3>");


$db->close();
}
?>
  </span>
  <!------ featured products ------>
</div>
</body>
</html>