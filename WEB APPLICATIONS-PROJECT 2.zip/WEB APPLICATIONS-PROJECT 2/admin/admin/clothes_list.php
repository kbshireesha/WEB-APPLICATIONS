  <?php
session_start();
include("../../db.php");

include "sidenav.php";
include "topheader.php";
include "clothes_list1.php";

?>
    <?php

include("../../db.php");
error_reporting(0);
if(isset($_GET['action']) && $_GET['action']!="" && $_GET['action']=='delete')
{
$product_id=$_GET['product_id'];
///////picture delete/////////
$result=mysqli_query($con,"select product_image from products where product_id='$product_id'")
or die("query is incorrect...");

list($picture)=mysqli_fetch_array($result);
$path="../../product_images/$picture";

if(file_exists($path)==true)
{
  unlink($path);
}
else
{}
/*this is delet query*/
mysqli_query($con,"delete from products where product_id='$product_id'")or die("query is incorrect...");
}

///pagination


?>

<html>
    <body>
        &nbsp; <div style="color:white;"> Item successfully deleted!</div><br>
        &nbsp; <div style="color:white;">Click here to go back to the <a href="products_list.php"><u>product-list</u></a></div>
    </body>
</html>