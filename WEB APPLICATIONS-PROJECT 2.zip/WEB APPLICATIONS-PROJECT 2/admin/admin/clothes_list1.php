  <?php 
include("../../db.php");
 
  ?>

  <div class="row" style="padding-top: 10vh;">
      
      <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
          <div class="card card-stats">
             
          </div>
      </div>
      <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
          <div class="card card-stats">
             

          </div>
      </div>
  </div>